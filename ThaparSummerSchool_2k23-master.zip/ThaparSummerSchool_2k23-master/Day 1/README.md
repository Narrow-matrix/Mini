
<ul>
<b>

<li>  Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force</li>
<li><a href="https://docs.google.com/document/d/1jndSf3CtX3KPrR3zNMZXhsV2I21E3dAmcswTvA8JydA/edit?usp=sharing">Link for Doc</a> </li>
</b>
</ul>

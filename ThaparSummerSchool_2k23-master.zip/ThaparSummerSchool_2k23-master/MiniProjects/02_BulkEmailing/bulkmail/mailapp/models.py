from django.db import models

# Create your models here.
class DATA(models.Model):
    location=models.FileField()

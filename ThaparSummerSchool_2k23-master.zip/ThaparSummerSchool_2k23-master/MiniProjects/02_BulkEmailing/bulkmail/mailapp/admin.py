from django.contrib import admin

from mailapp.models import DATA
# Register your models here.
admin.site.register(DATA)
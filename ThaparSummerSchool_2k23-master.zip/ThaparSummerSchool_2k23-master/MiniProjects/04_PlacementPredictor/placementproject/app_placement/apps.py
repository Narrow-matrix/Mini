from django.apps import AppConfig


class AppPlacementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_placement'
